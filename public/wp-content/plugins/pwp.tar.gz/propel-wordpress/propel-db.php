<?php

/**
 * Creates the necessary database checks and upgrades,
 *   adding the 'propel_enrollments' table if necessary
 *
 * Assumes class is instantiated because upgrades are needed.
 *
 * Propel_DB instantiation is in Propel_LMS->check_db_upgrade()
 *
 * @author caseypatrickdriscoll
 *
 * @created 2015-01-07 12:00:00
 * @edited  2015-01-08 14:53:39
 * @edited  2015-01-16 10:18:20
 */
class Propel_DB {

  const VERSION = 4;
  const enrollments_table = 'propel_enrollments';

  public function __construct() {
    self::upgrade_db();
  }


  /**
   * Upgrades the database as necessary,
   *   sets the database version in settings
   *
   * @author caseypatrickdriscoll
   *
   * @created 2015-01-07 12:00:00
   * @edited  2015-01-16 09:57:30
   */
  private function upgrade_db() {
    
    if ( ! $this->enrollments_table_exists() )
      $this->create_enrollments_table();


    if ( self::VERSION == 2 )
      $this->add_activation_key_to_enrollments_table();

    if ( self::VERSION == 3 )
      $this->add_completion_date_to_enrollments_table();

    if ( self::VERSION == 4 )
      $this->add_passed_to_enrollments_table();

    // Update version setting
    $propel_settings = get_option( 'propel_settings' );
    if ( isset( $propel_settings ) )
      $propel_settings['db_version'] = self::VERSION;
    else
      $propel_settings = array( 'db_version' => self::VERSION );

    update_option( 'propel_settings', $propel_settings );
  }


  /**
   * Creates the propel_enrollments table
   *
   * @author caseypatrickdriscoll
   *
   * @created 2015-01-07 12:00:00
   */
  private function create_enrollments_table() {
    global $wpdb;

    $wpdb->hide_errors();

    // $collate declaration taken from WooCommerce
    $collate = '';

    if ( $wpdb->has_cap( 'collation' ) ) {
      if ( ! empty( $wpdb->charset ) ) {
        $collate .= "DEFAULT CHARACTER SET $wpdb->charset";
      }
      if ( ! empty( $wpdb->collate ) ) {
        $collate .= " COLLATE $wpdb->collate";
      }
    }

    $create = "
      CREATE TABLE {$wpdb->prefix}" . Propel_DB::enrollments_table . "(
        ID bigint(20) NOT NULL AUTO_INCREMENT,
        post_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        activation_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        expiration_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        UNIQUE KEY  ID (ID),
        KEY post_id (post_id),
        KEY user_id (user_id)
      ) $collate
    ";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $create );

  }

  function add_completion_date_to_enrollments_table() {
    error_log("=== ADDING COMPLETION DATE TO ENTOLLMENTS");
    global $wpdb;
    $add_key = "
      ALTER TABLE {$wpdb->prefix}" . Propel_DB::enrollments_table . "
        ADD completion_date DATETIME
    ";

    $wpdb->query( $add_key );  
  }

  function add_passed_to_enrollments_table() {
    error_log("=== ADDING PASSED COLUMN TO ENTOLLMENTS");
    global $wpdb;
    $add_key = "
      ALTER TABLE {$wpdb->prefix}" . Propel_DB::enrollments_table . "
        ADD passed bool
    ";

    $wpdb->query( $add_key );  
  }

  /**
   * Adds 'activation_key' column varchar(20) to propel_enrollments table
   *
   * @author  caseypatrickdriscoll
   *
   * @created 2015-01-16 10:04:05
   *
   * @return  void
   */
  function add_activation_key_to_enrollments_table() {
    global $wpdb;

    $add_key = "
      ALTER TABLE {$wpdb->prefix}" . Propel_DB::enrollments_table . "
        ADD activation_key VARCHAR(20)
    ";

    $wpdb->query( $add_key );

  }


  /**
   * Does a quick count query, returning 1+ for exists and 0 for not exists
   *
   * @author caseypatrickdriscoll
   *
   * @created 2015-01-07 12:00:00
   *
   * @return boolean   $exists   Non zero number if table already exists
   */
  private function enrollments_table_exists() {
    global $wpdb;

    $exists = "
      SELECT COUNT(1) 
      FROM information_schema.tables 
      WHERE table_schema='%s' 
        AND table_name='%s';
    ";

    $exists = $wpdb->get_results(
                $wpdb->prepare(
                  $exists,
                  $wpdb->dbname,
                  $wpdb->prefix . Propel_DB::enrollments_table
                ),
                ARRAY_N
              );

    return $exists[0][0];
  }

}
