propel-wordpress
================

WordPress Plugin to work with Propel-LMS

## Overrides

The LearnDash plugin uses an inefficient means to store user-course enrollment relationships, post meta data.

We rewrote the functionality using a custom propel_enrollments table, but parts of the LearnDash plugin needed to be changed to check this table instead of it's given functionality.

Instead of forking the LearnDash plugin, I decided it would be best for now to inject it with a few lines of code, with this reminder (and a js alert in the plugin) to re-add them on upgrade. PHP function overrides are not available like I thought.

Ultimately, you are preventing the use of the post_meta 'sfwd-courses_course_access_list' and exchanging it for the use of the propel_enrollments table;

To override the necessary functions, add these TWO lines of code.

1) Include overrides file

In sfwd-lms/sfwd_lms.php at the top of the file before the 'requires' add:

````
include WP_PLUGIN_DIR . '/propel-lms/learndash-overrides.php';
````

This will load the necessary functions and all set the GLOBAL['learndash-overrides'] to prevent the built in js alerts.


2) Override sfwd_lms_has_access

In sfwd-lms/sfwd_lms.php at the top of the sfwd_lms_has_access function add:

````
return override_sfwd_lms_has_access( $post_id, $user_id );
````

This will short the function appropriately and prevent it from running as designed.