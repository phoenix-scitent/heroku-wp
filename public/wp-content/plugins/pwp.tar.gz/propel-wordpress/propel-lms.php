<?php

/** 
 * Plugin Name: PROPEL by Scitent
 * Version: 2015-05-01 15:46:47
 * Author: Casey Patrick Driscoll
 * Author URI: http://caseypatrickdriscoll.com
 * Description: Scitent OKM WooCommerce and Learndash integration
 */

include 'propel-widget.php';
include 'propel-shortcodes.php';
include 'propel-settings.php';
include 'propel-course-product.php';
include 'propel-org-admin.php';
include 'propel-db.php';
include 'propel-migrate-course-completion.php';
include 'learndash-overrides.php';
include 'propel-reports.php';

/**
 * The Propel_LMS class handles the integration of LearnDash and WooCommerce,
 *
 *   It creates the necessary ancillary components (like pages and roles)
 *   to make the system run fully and completely.
 *
 *   It also integrates with the proprietary Scitent 'OKM',
 *   a course enrolment key management API system, hosted on a separate server
 *
 * Customers will typically purchase a LearnDash course enrollment through WooCommerce.
 *   At the time the WooCommerce purchase is complete
 */
class Propel_LMS {


	// Who to email in check_tenant_key. Can be comma separated list
	const OKM_SUPPORT = 'ljeanmarius@scitent.com';

	// Returned from self::okm_server() if no option set.
	// Declared here for access
	const OKM_SERVER  = 'https://propellms.com';

	// Used as a helpful hint in Propel_Settings::okm_server_callback()
	// Declared here for access
	const OKM_STAGING = '107.21.224.181';


	function __construct() {

		register_activation_hook( __FILE__, 
			array( $this, 'create_necessary_pages' ) );

		register_activation_hook( __FILE__,
			array( $this, 'create_necessary_roles' ) );

		add_action( 'plugins_loaded',
			array( $this, 'check_db_upgrade' ) );

		add_action( 'admin_menu',
			array( $this, 'add_propel_okm_menu' ) );


		add_action( 'woocommerce_checkout_billing',
			array( $this, 'check_tenant_key' ) );

		add_action( 'woocommerce_review_order_before_payment',
			array( $this, 'auto_enroll_render_form' ) );

		add_action( 'woocommerce_order_status_on-hold', 
			array( $this, 'hook_thank_you_email' ) );

		add_action( 'woocommerce_order_status_completed',
			array( $this, 'request_keys' ), 1, 3 );
		add_action( 'woocommerce_order_status_processing',
			array( $this, 'request_keys' ), 1, 3 );

		add_action( 'woocommerce_order_status_completed',
			array( $this, 'auto_enroll_user_in_course' ), 2, 3 );

		add_action( 'woocommerce_order_status_processing',
			array( $this, 'auto_enroll_user_in_course' ), 2, 3 );

		add_action( 'woocommerce_thankyou', 
			array( $this, 'redirect_after_purchase' ) );

		add_action( 'woocommerce_view_order',
			array( $this, 'view_order_okm_keys' ) );


		add_action( 'wp_ajax_activate_key',
			array( $this, 'ajax_activate_key' ) );


		add_action( 'template_redirect',
			array( $this, 'download_csv' ) );


		// Actions for refunds
		add_action( 'admin_enqueue_scripts',
			array( $this, 'refund_script' ) );

		add_action( 'save_post_shop_order',
			array( $this, 'refund_orders' ) );


		add_filter( 'woocommerce_return_to_shop_redirect', array($this,'override_empty_cart_button_url') );
		add_filter( 'sfwd_lms_has_access', 'override_sfwd_lms_has_access' );
    }

    function override_empty_cart_button_url () {
            $propel_settings = get_option( 'propel_settings' );
            if ( isset($propel_settings['store_url'])) {
                    return $propel_settings['store_url'];
            } else {
                    return get_site_url();
            }
    }


		/**
		 * Queries the DB for the given enrollment,
		 *   conditionally returning the enrollment key or false if not active or non-existent
		 *
		 * TODO: Consider multiple enrollments
		 *
		 * @author  caseypatrickdriscoll
		 *
		 * @created 2015-01-16 12:41:51
		 *
		 * @param   int      $user_id          The requested user
		 * @param   int      $course_id        The post id of the requested course
		 *
		 * @return  string   $activation_key   The key of the given enrollment
		 * @return  bool     false             The key is not active or enrollment doesn't exist
		 */
		static function get_active_enrollment( $user_id, $course_id ) {
			global $wpdb;

			$propel_table = $wpdb->prefix . Propel_DB::enrollments_table;

			$enrollment = $wpdb->get_row( "
														SELECT *
														FROM $propel_table 
														WHERE user_id = $user_id
															AND post_id = $course_id
													" );

			if ( current_time( 'mysql' ) < $enrollment->expiration_date )
				return $enrollment->activation_key;
			else
				return false;

		}


		/**
		 * Checks to see if database needs an upgrade then does it
		 *
		 * Only checks on plugins_loaded, can't check on plugin upgrade/registration
		 * http://codex.wordpress.org/Creating_Tables_with_Plugins
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-01-08 14:32:28
		 * @edited  2015-01-16 16:48:52
		 *
		 * @action plugins_loaded
		 */
		function check_db_upgrade() {
			$settings = get_option( 'propel_settings' );
			if ( isset( $settings ) && intval( $settings['db_version'] ) < Propel_DB::VERSION )
				new Propel_DB();
		}


		/**
		 * Registers admin menu page for OKM
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-05-01 13:01:34
		 */
		function add_propel_okm_menu() {
			add_menu_page(
				'PROPEL OKM',
				'PROPEL OKM',
				'view_tenant_okm',
				'propel-okm',
				array( $this, 'render_propel_okm' ),
				'',
				10
			);
		}


		/**
		 * Renders OKM in the admin
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-05-01 13:00:59
		 */
		function render_propel_okm() {
			global $current_user;
			get_currentuserinfo();

			if ( ! current_user_can( 'view_tenant_okm' ) ) return;

			$width = '100%';
			$height = '3000';

			$propel_settings = get_option( 'propel_settings' );
			$tenant_secret_key = $propel_settings['okm_tenant_secret_key'];

			$auth_array = array(
				'tenant_secret_key' => $tenant_secret_key,
				'first_name'        => $current_user->user_firstname,
				'last_name'         => $current_user->user_lastname,
				'ext_user_id'       => $current_user->ID,
				'email'             => $current_user->user_email
			);

			$propel_org_admin = get_user_meta( $current_user->ID, 'propel_org_admin', true );

			if ( ! empty( $propel_org_admin ) ) $auth_array['org_id'] = $propel_org_admin;

			$response = Propel_LMS::ping_api( $auth_array, 'authenticate' );

			$okm_token = $response['auth_token'];

			$out = '<iframe src="' . Propel_LMS::okm_server() . '/accounts/' . $okm_token . '/sign_in' . '" width="' . $width . '" height="' . $height . '" frameborder="0" scrolling="auto"></iframe>';

			echo $out;
		}


		/**
		 * Creates WordPress pages for user registration and interaction
		 *   - Terms of Service
		 *   - Activate Key
		 *   - My Courses
		 *   - OKM
		 *   - Order On-Hold
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @edited 2015-01-07 16:50:09
		 * @edited 2015-01-09 16:23:26
		 * @edited 2015-03-09 09:34:32 - Adds 'Order On-Hold' Page
		 *
		 * @action on plugin activation
		 */
		function create_necessary_pages() {
			$user_id = get_current_user_id();

			// 1. Create 'Terms of Service' page
			if ( ! isset( get_page_by_title( 'Terms of Service' )->ID ) ) { 

				$page_content = file_get_contents( plugin_dir_path( __FILE__ ) . 'terms-of-service.txt' );

				$terms_of_service_page = array(
					'post_title' => 'Terms of Service',
					'post_content' => $page_content,
					'post_status' => 'publish',
					'post_type' => 'page',
					'post_author' => $user_id
				);

				wp_insert_post( $terms_of_service_page );

			}


			// 2. Create 'Activate Key' page
			if ( ! isset( get_page_by_title( 'Activate Key' )->ID ) ) {

				$page_content = 'Access to and use of ' . get_bloginfo( 'url' ) . ' is subject to the following terms and conditions. Please read these terms and conditions carefully before activating a course key. Completing the key activation process indicates that you accept and agree to abide by these terms and conditions set forth by the ' . get_bloginfo( 'name' ) . '.';

				$page_content .= "\n\n";
				$page_content .= '[propel-key-activator]';

				$page_content .= "\n\n";
				$page_content .= '[propel-terms-of-service]';

				$page_content .= "\n\n";
				$page_content .= '[propel-key-submit]';

				$activate_key_page = array(
					'post_title' => 'Activate Key',
					'post_content' => $page_content,
					'post_status' => 'publish',
					'post_type' => 'page',
					'post_author' => $user_id 
				);

				wp_insert_post( $activate_key_page );

			}


			// 3. Create 'My Courses' page
			if ( ! isset( get_page_by_title( 'My Courses' )->ID ) ) { 

				$page_content = '[ld_course_list mycourses="true"]';

				$my_courses_page = array(
					'post_title' => 'My Courses',
					'post_content' => $page_content,
					'post_status' => 'publish',
					'post_type' => 'page',
					'post_author' => $user_id 
				);

				wp_insert_post( $my_courses_page );

			}


			$propel_settings = get_option( 'propel_settings' );

			// 4. Create 'OKM' page
			if ( ! isset( $propel_settings['okm_page_id'] ) ) {

				$org_id = get_the_author_meta( 'propel_org_admin', $user_id ); 

				$page_content = '[propel-okm]';

				$okm_page = array(
					'post_title' => 'OKM',
					'post_content' => $page_content,
					'post_status' => 'private',
					'post_type' => 'page',
					'post_author' => $user_id
				);

				$okm_page_id = wp_insert_post( $okm_page );

				if ( isset( $propel_settings ) )
					$propel_settings['okm_page_id'] = $okm_page_id;
				else
					$propel_settings = array( 'okm_page_id' => $okm_page_id );

				update_option( 'propel_settings', $propel_settings );

			}


			// 5. Create 'Order On-Hold'
			if ( ! isset( $propel_settings['order_on_hold_page_id'] ) ) {

				$page_content = 'Thank you for placing a purchase order with us. We will send you your access keys once we approve the PO.';

				$order_on_hold_page = array(
					'post_title'   => 'Order On-Hold',
					'post_content' => $page_content,
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_author'  => $user_id
				);

				$order_on_hold_page_id = wp_insert_post( $order_on_hold_page );

				if ( isset( $propel_settings ) )
					$propel_settings['order_on_hold_page_id'] = $order_on_hold_page_id;
				else
					$propel_settings = array( 'order_on_hold_page_id' => $order_on_hold_page_id );

				update_option( 'propel_settings', $propel_settings );

			}

		}


		/**
		 * Creates the 'org_admin' role by duplicating the administrator role
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-01-08 15:06:54
		 * @edited  2015-01-08 16:01:28
		 *
		 * @action register_activation_hook
		 */
		function create_necessary_roles() {
			Propel_Org_Admin::create_role();
		}


		/**
		 * Checks that the tenant key is installed or kills the system
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-01-29 15:35:20
		 *
		 * @params string   $action   A descriptor of the action the user was trying
		 *
		 * @return void
		 */
		function check_tenant_key( $action ) {
			$propel_settings = get_option( 'propel_settings' );

			if ( isset( $propel_settings['okm_tenant_secret_key'] ) ) return;

			echo '<p>There is an error, the OKM tenant key is missing.</p>';
			echo '<p>Please contact the Scitent administrator at <a href="mailto:' . self::OKM_SUPPORT . '">' . self::OKM_SUPPORT . '</a>.</p>';

			if ( empty( $action ) ) {

				// $action completes the phrase 'user was trying to $action.'
				switch ( current_action() ) {
					case woocommerce_checkout_billing:
						$action = 'check out';
						break;
					default:
						$action = '(action is unknown)';
						break;
				}

			}

			wp_mail(
				self::OKM_SUPPORT,
				'FAILURE: No tenant key installed at ' . get_bloginfo( 'name' ),
					'The website ' . get_home_url() . ' is currently down.

				Users are not currently able to purchase or activate keys.

				The user "' . wp_get_current_user()->user_nicename . '" was trying to ' . $action . '.

				Please enter the tenant key at ' . admin_url( 'options-general.php?page=propel-settings&tab=license' )
			);

			die();
		}


		/**
		 * Renders checkboxes at the end of checkout for product (possible multiple-course) auto-enrollment
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @edited 2015-01-29 17:17:04 - Doesn't render non-course products
		 *
		 * @action woocommerce_review_order_before_payment 
		 */
		function auto_enroll_render_form() { 
			global $current_user;

			if ( array_shift( $current_user->roles ) != 'org_admin' )
				$checked = true;

			?>
			<h3>Auto Enrollment</h3>
			<p>Check the box to auto-enroll your account.</p>

			<table class="shop_table">
				<thead>
					<tr>
						<th style="width:20px;"></th>
						<th>Product</th>
					</tr> <?php
					
					foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) { 
						$product = $cart_item['data']->post->ID;

						$is_course = get_post_meta( $product, '_related_course', true );
						if ( empty( $is_course ) ) continue;

						?>
						<tr>
							<td>
								<input name="enroll[<?php echo $product; ?>]"  
											 id="enroll[<?php echo $product; ?>]"  
											 type="checkbox" 
											 <?php if ( $checked ) echo 'checked'; ?> />
							</td>
							<td>
								<label for="enroll[<?php echo $product; ?>]">
									<?php echo get_the_title( $product ); ?>
								</label>
							</td>
						</tr> <?php
					} ?>

				</thead>
			</table> <?php
		}


		/**
		 * Enroll user in product's courses if selected during checkout
		 *
		 * @author  caseypatrickdriscoll
		 *
		 * @edited  2015-01-19 17:30:20
		 *
		 * @action  woocommerce_order_status_completed
		 *
		 * @return  void
		 */ 
		function auto_enroll_user_in_course( $order_id ) {
			$user = wp_get_current_user();
			$propel_settings = get_option( 'propel_settings' );

			$enrollments = $_POST['enroll'];
			$order = new WC_Order( $order_id );

			$session['items'] = count( $order->get_items() );

			$post_data = array(
				'tenant_secret_key' => $propel_settings['okm_tenant_secret_key'], 
				'ext_user_id' => $user->ID,
				'first_name' => $user->user_firstname,
				'last_name' => $user->user_lastname,
				'email' => $user->user_email,
			);

			foreach ( $enrollments as $product => $enroll ) {
				$key = $this->pluck_key( $order_id, $product );

				$post_data['code'] = $key;

				// @TODO: Check response
				$response = self::ping_api( $post_data, 'activate_key' );

				$courses = get_post_meta( $product, '_related_course', true );

				foreach ( $courses as $course ) {
					$this->update_course_access( $user->ID, $course, $key );

					$session['course_id'] = $course;
				}

			}

			update_user_meta( get_current_user_id(), 'session', $session );
		}


		/**
		 * Returns the first key for a product
		 *   To be used only for auto-enrollment, when we know the first key is not used yet
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-01-16 12:23:01
		 *
		 * @return string   $key   The 0th key of the given product
		 */
		function pluck_key( $order_id, $product_id ) {

			$keys = get_post_meta( $order_id, '_keys' );

			$sku = get_post_meta( $product_id, '_sku', true );

			// TODO: Save keys outside of embedded array
			foreach ( $keys[0] as $product )
				if ( $product['product_sku'] == $sku )
					return $product['keys'][0];

		}


		/**
		 * Redirects to conditional page after purchase
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-01-05 12:00:00
		 * @edited  2015-01-07 22:00:21
		 * @edited  2015-01-16 16:49:24 - Fixes portability problem
		 * @edited  2015-01-20 10:40:20 - Redirects on 'org_admin' not 'administrator'
		 * @edited  2015-03-09 09:39:53 - Adds wc-on-hold purchase redirect
		 *
		 * @action woocommerce_thankyou
		 */
		function redirect_after_purchase() {   
			global $current_user;
			global $wp;

			$propel_settings = get_option( 'propel_settings' );

			$order_post = get_post( $wp->query_vars['order-received'] );


			if ( $order_post->post_status == 'wc-on-hold' ) {
				// Redirect to the special page
				$order_on_hold_page = get_post( $propel_settings['order_on_hold_page_id'] );

				if ( ! is_null( $order_on_hold_page ) ) {
					wp_redirect( get_permalink( $order_on_hold_page->ID ) );
					exit();
				}

			}


			$session = get_user_meta( $current_user->ID, 'session' );
			$session = $session[0];
			delete_user_meta( $current_user->ID, 'session' );


			if ( array_shift( $current_user->roles ) != 'org_admin' ) {

				// If a normal user bought multiple courses, take them to course central
				if ( $session['items'] > 1 ) {
					wp_redirect( home_url() . '/my-courses/' );
					exit;
				// Else a normal user bought a single course
				} else {

					// If they auto-enrolled, take them to the course
					// Otherwise, just show them their receipt per usual
					if ( isset( $session['course_id'] ) ) {
						wp_redirect( get_permalink( $session['course_id'] ) );
						exit;
					}
				}

			} else {

				wp_redirect( get_permalink( $propel_settings['okm_page_id'] ) );
				exit;

			}

		}


		/**
		 * Adds instructions to the customer thank you email
		 *
		 * @author  caseypatrickdriscoll
		 *
		 * @action  woocommerce_order_status_on-hold
		 *
		 * @return  void
		 */
		function hook_thank_you_email() {
			add_action( 'woocommerce_email_order_meta', function( $o, $sent_to_admin, $p ) {
				if ( ! $sent_to_admin ) {
					echo '<h2>Instructions</h2>';

					// TODO: Consider proper language in this email
					echo '<p>Your payment is awaiting approval, keys will be sent upon review and approval of your order.</p>';
				}
			}, 10, 3);


		}


		/**
		 * Requests key generation from the Scitent OKM server when order completed
		 * Saves keys to Order post_meta and attaches to customer order complete email
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @edited 2015-01-16 16:54:48
		 * @edited 2015-01-19 17:31:59 - Uses new self::ping_api()
		 * @edited 2015-01-29 17:09:30 - Doesn't request keys if no courses
		 * @edited 2015-01-29 17:13:29 - Unsets $keychain['http_status'] if exists
		 * @edited 2015-01-30 09:59:55 - Only adds org_id if set
		 *
		 * @param	WC_Order	$order_id	The order object
		 *
		 * @action	woocommerce_order_status_completed
		 */
		function request_keys( $order_id ) {
			$order = new WC_Order( $order_id );

			$keys = get_post_meta( $order_id, '_keys', true );

			if ( ! empty( $keys ) ) return;

			$products = $order->get_items();

			$user = $order->get_user();

			$first_name = $user->first_name ? $user->first_name : $order->billing_first_name;
			$last_name  = $user->last_name ? $user->last_name : $order->billing_last_name;



			$propel_settings = get_option( 'propel_settings' );

			self::check_tenant_key( 'request keys' );

			$post_data = array(
				'tenant_secret_key' => $propel_settings['okm_tenant_secret_key'], 
				'ext_user_id' => $user->ID,
				'first_name' => $first_name,
				'last_name' => $last_name,
				'email' => $user->user_email,
				'order_number' => $order->id,
				'products' => array()
			);


			/* SENDING THE ORGANIZATION_ID TO THE OKM */

			// The OKM stores 'organizations' in its database
			// When generating keys, it needs to know if there is a corresponding organization
			//
			// The top priority is for 'Org Admins' who have the OKM tied to their wp user account
			// Send this OKM org id to the OKM if it exists
			$okm_org_id = get_the_author_meta( 'propel_org_admin', $user->ID );

			// If the 'Org Admin' id doesn't exist (empty), it means the purchaser is an ordinary user/customer
			// When ordinary user/customers are created/saved, they select an 'Organization' (example: League and Team)
			// The preferred organization id is duplicated in the usermeta table as 'propel_okm_org_id'
			// 'propel_okm_org_id' is stored as the wp_posts.ID though, NOT the OKM org id
			// The OKM org id is stored on the post_meta, as '_org_id'
			//
			// So if the $okm_org_id is currently empty (user is not an org admin)
			// Try getting the '_org_id' post_meta on the given 'propel_okm_org_id' propel_org
			//    (As example, this will be the OKM organization_id of '12' as opposed to the wp_posts.ID of 3300)
			if ( empty( $okm_org_id ) ) {
				$okm_org_id = get_the_author_meta( 'propel_okm_org_id', $user->ID );
				$okm_org_id = get_post_meta( $okm_org_id, '_org_id', true );
			}

			// If there is an OKM org id, send it in the request
			// If not, don't send an organization_id at all
			if ( ! empty( $okm_org_id ) )
				$post_data['organization_id'] = $okm_org_id;


			foreach( $products as $product ) {
				// Make sure it is a course product
				$is_course = get_post_meta( $product['product_id'], '_related_course', true );
				if ( empty( $is_course ) ) continue;

				$new_product = array(
					'product_sku' => get_post_meta( $product['product_id'], '_sku', true ), 
					'product_name' => $product['name'],
					'quantity' => $product['item_meta']['_qty'][0]
				);
				array_push( $post_data['products'], $new_product );
			}

			// No courses bought
			if ( empty( $post_data['products'] ) ) return;

			// Sends generate key request to OKM server, returns keys
			$keychain = self::ping_api( $post_data, 'generate_keys' );

			if ( isset( $keychain['http_status'] ) ) unset( $keychain['http_status'] );

			// TODO: Validate if $keychain correct data or error, duh
			update_post_meta( $order_id, '_keys', $keychain, true );

			add_action( 'woocommerce_email_order_meta', 
				array( $this, 'print_keys' ), 10, 2 );
		}


		/**
		 * Sends curl to Scitent OKM server and receives response
		 *   Possible methods include:
		 *     - generate_keys
		 *     - activate_key
		 *     - validate_tenant
		 *
		 * @author  caseypatrickdriscoll
		 *
		 * @edited  2015-01-19 16:16:18
		 * @edited  2015-01-19 17:32:23 - Abstracts for GETs and POSTs
		 * @edited  2015-01-30 10:00:22 - Updates to ssl
		 * @edited  2015-04-07 11:41:51 - Refactors to require http/https in the URI setting
		 *
		 * @param   array   $request        Array of customer and product data 
		 * @param   array   $method         The api method to call
		 *
		 * @return  array   $responseData   The response from the OKM	
		 */
		static function ping_api( $request, $method, $action = 'POST' ) {

			$url = self::okm_server() . '/api/' . $method;

			// If is it is a string (not array), add it to the end of the url
			// For example, ?tenant_secret_key=xxxxxxxxxxx
			if ( ! is_array( $request ) )
				$url .= $request;

			$ch = curl_init( $url );

			if ( $action == 'POST' )
				curl_setopt( $ch, CURLOPT_POST, TRUE );

			if ( is_array( $request ) )
				curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $request ) );

			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
			curl_setopt( $ch, CURLINFO_HEADER_OUT, TRUE);
			curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, FALSE);
			curl_setopt( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; rv:26.0) Gecko/20100101 Firefox/26.0'); 

			curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
				'Accept: application/json',
				'Content-Type: application/json'
			) );
				
			// Send the request
			$response = curl_exec( $ch );

			// Check for errors
			if ( $response === FALSE ) {
				die( curl_error( $ch ) );
			}

			// Decode the response
			$responseData = json_decode( $response, TRUE );

			$responseData['http_status'] = curl_getinfo( $ch, CURLINFO_HTTP_CODE );

			curl_close( $ch );

			return $responseData;
		}


		/**
		 * Renders the keys attached to the given order, mainly for customer email
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @action	woocommerce_email_order_meta
		 *
		 * @param	WC_Order  $order	          The WooCommerce order	
		 * @param	bool      $sent_to_admin    If the email is sent to admin 
		 */
		function print_keys( $order, $sent_to_admin ) {
			if ( $sent_to_admin ) return;

			echo '<h2>Keys</h2>  ';

			$products = $order->get_items();

			$keychain = get_post_meta( $order->id, '_keys' );
			$keychain = $keychain[0];

			foreach ( $keychain as $product ) {
				echo '<h4> ( for sku: ' . $product['product_sku'] . ' ) </h4>  ';

				// TODO: Check styling in email for funky word wrap
				echo '<pre> ' . implode( " ", $product['keys'] ) . ' </pre>';
			}
		}


		/**
		 * The ajax POST controller for activating keys on the OKM
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @edited  2015-01-19 17:32:55 - Uses new self::ping_api
		 *
		 * @action  wp_ajax_activate_key
		 *
		 * @return  wp_send_json_success || wp_send_json_error
		 */
		function ajax_activate_key() {
			global $wpdb;

			$key = $_POST['key'];
			$user = wp_get_current_user();
			$propel_settings = get_option( 'propel_settings' );

			$post_data = array(
				'tenant_secret_key' => $propel_settings['okm_tenant_secret_key'], 
				'ext_user_id' => $user->ID,
				'first_name' => $user->user_firstname,
				'last_name' => $user->user_lastname,
				'email' => $user->user_email,
				'code' => $key	
			);


			$response = self::ping_api( $post_data, 'activate_key' );


			if ( array_key_exists( 'code', $response ) )
				$response['success'] = true;
			else
				$response['success'] = false;


			if ( ! $response['success'] )
				wp_send_json_error( $response );

			$product_query = "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1";

			$product_id = $wpdb->get_var( 
							$wpdb->prepare( 
								$product_query,										
								$response['product_sku'] 
							) );

			if ( $product_id ) 
				$product = new WC_Product( $product_id );
			else {
				$respsonse['success'] = false;
				$respsonse['msg'] = 'No product with that sku';
				wp_send_json_error( $response );
			}

			$courses_id = get_post_meta( $product_id, '_related_course', true );
			$course_id;

			if ( $courses_id && is_array( $courses_id ) ) {
				// TODO: Shouldn't we see if user exists already in the list?
				foreach ( $courses_id as $cid ) {
					$this->update_course_access( get_current_user_id(), $cid, $key );
					$course_id = $cid;
				}
			}
			
			$response['msg'] = 'Works great!';
			$response['url'] = get_permalink( $course_id );

			wp_send_json_success( $response );
		}


		/**
		 * Attaches user to Course Post through post meta
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @from   activate_key()
		 * 
		 * @param  int   $user_id     The user id
		 * @param  int   $course_id   The course id
		 * @param  bool  $remove      Flag to remove user
		 *
		 * @return array $meta        Array of course meta information
		 */
		function update_course_access( $user_id, $course_id, $key, $remove = false ) {
			if ( empty( $user_id ) || empty( $course_id ) )
				return;

			// Set to propel_enrollments
			global $wpdb;

			$propel_table = $wpdb->prefix . Propel_DB::enrollments_table;

			$exists = $wpdb->get_var( "
												SELECT COUNT(*) 
												FROM $propel_table 
												WHERE user_id = $user_id
													AND post_id = $course_id
											" );

			if ( ! $exists ) {

				$expiration = date_format(
												date_add(
													date_create( current_time( 'mysql' ) ),
													date_interval_create_from_date_string( '365 days' )
												),
												'Y-m-d H:i:s'
											);

				$wpdb->insert( 
								$wpdb->prefix . Propel_DB::enrollments_table,
								array( 
									'post_id' => $course_id,
									'user_id' => $user_id,
									'activation_date' => current_time( 'mysql' ),
									'expiration_date' => $expiration,
									'activation_key'  => $key
								)
							);

			}

		}


		/**
		 * Returns the name of okm server, if saved in settings
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-02-09 13:27:53
		 *
		 * @return   string   The okm_server setting
		 */
		static function okm_server() {

			$settings = get_option( 'propel_settings' );

			if ( isset( $settings['okm_server'] ) && ! empty( $settings['okm_server'] ) )
				return $settings['okm_server'];
			else
				return self::OKM_SERVER;
		}


		/**
		 * Finds enrollment by given params
		 *
		 * This returns a *single* enrollment, so will only return the first if multiple found
		 *
		 * - enrollment_id
		 * - user_id
		 * - activation_date
		 * - activation_key
		 *
		 * @author   caseypatrickdriscoll
		 *
		 * @created  2015-02-18 12:23:51
		 *
		 * @param    $atts
		 *
		 * @return   Array   $enrollment   Associative array of the requested enrollment
		 */
		function get_enrollment( $atts ) {

			if ( is_array( $atts ) ) extract( $atts );

			global $wpdb;
			$propel_table = $wpdb->prefix . Propel_DB::enrollments_table;


			$query = "SELECT *
                FROM $propel_table
                ";


			if ( isset( $activation_key ) ) {
				$query .= "WHERE activation_key = '" . $activation_key . "'
                  ";
			}

			$query .= "LIMIT 1";


			$enrollment = $wpdb->get_row( $query, ARRAY_A );

			return $enrollment;
		}


		/**
		 * Checks the enrollment_table for a record with the given key,
		 *   returning 1 or 0 if the record exists or not
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-02-19 10:46:16
		 *
		 * @param  string   $key      The requested activation_key
		 *
		 * @return int      $active   1 if the key exists in the table, 0 if not
		 */
		function is_enrollment_active( $key ) {

			global $wpdb;
			$propel_table = $wpdb->prefix . Propel_DB::enrollments_table;

			// Will return 0 or 1 depending if record exists
			$active = $wpdb->get_var( "
			            SELECT COUNT(*)
			            FROM $propel_table
			            WHERE activation_key = '$key'
			              AND expiration_date > NOW()
			          " );

			return $active;
		}

		function is_enrollment_expired( $key ) {

			global $wpdb;
			$propel_table = $wpdb->prefix . Propel_DB::enrollments_table;

			// Will return 0 or 1 depending if record exists
			$active = $wpdb->get_var( "
			            SELECT COUNT(*)
			            FROM $propel_table
			            WHERE activation_key = '$key'
			              AND expiration_date < NOW()
			          " );

			return $active;
		}


		/**
		 * Renders a table of keys for each product on the view-order page in WooCommerce
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-02-19 10:37:49
		 *
		 * @param  int   $order_id   The given WC_Order id
		 *
		 * @return void
		 */
		function view_order_okm_keys( $order_id ) {

			global $wpdb;
			$post_7 = get_post($order_id); 
			$order_status = $post_7->post_status;
			if ($order_status == 'wc-refunded') {
				return false;
			}

			$product_keys = get_post_meta( $order_id, '_keys' );

			$product_keys = $product_keys[0];

			echo '<h2>Product Keys</h2>';


			foreach ( $product_keys as $product ) {

				if ( count( $product['keys'] ) >= 50 ) continue;

				$product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $product['product_sku'] ) );

				if ( $product_id ) $woo_product = new WC_Product( $product_id );
				else $woo_product = null;

				echo '<table class="shop_table">
								<thead>
									<tr>
										<th colspan="3">' . $woo_product->post->post_title .' [SKU: ' . $product['product_sku'] . ']</th>
										<th><i>' . count( $product['keys'] ) . ' Keys</i></th>
									</tr>
									<tr>
										<th class="product-key-code">Key Code</th>
										<th class="product-status">Status</th>
										<th class="product-user-enrolled">User Enrolled</th>
										<th class="product-date-enrolled">Date Enrolled</th>
									</tr>
								</thead>
								<tbody>';

				foreach ( $product['keys'] as $key ) {

					$status = $this->is_enrollment_active( $key ) == 0 ? 'Available' : 'Enrolled';
					$status = $this->is_enrollment_expired( $key ) == 0 ? $status : 'Expired';

					if ( $status == 'Enrolled' ) {
						$enrollment = $this->get_enrollment( array( 'activation_key' => $key ) );
						$user = get_user_by( 'id', $enrollment['user_id'] );
						$user_out = $user->user_nicename;
					} else {
						$enrollment = null;
						$user = null;
						$user_out = null;
					}

					echo '<tr>';
					echo   '<td>' . $key . '</td>';
					echo   '<td>' . $status . '</td>';
					echo   '<td>' . $user_out . '</td>';
					echo   '<td>' . $enrollment['activation_date'] . '</td>';
					echo '</tr>';
				}

				echo '</tbody></table>';
			}
      error_log("Order History for: ".$order_id);

			echo '<p><a class="button button-default propel-download-csv" href="/my-account/view-order/' . $order_id . '.csv" target="_blank">Download CSV</a></p>';
		}


		/**
		 * Initiates a csv download of the given order_id
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-02-19 11:01:16
		 *
		 * @edited  2015-02-27 10:41:01 - Adds product name and SKU
		 * @edited  2015-02-27 12:03:04 - Refactors to use fopen
		 * @edited  2015-03-09 15:04:10 - Refactors to send 200 http response
		 *
		 * @return void
		 */
		function download_csv() {

			$request_uri = explode( '/', rtrim($_SERVER['REQUEST_URI'],"/") );

			$end = end( $request_uri );
  		error_log("Order CSV for: ".$end);

			if ( substr( $end, -4 ) != '.csv' ) return;

			if ( ! is_user_logged_in() ) {

				auth_redirect();
				exit();
			}

			$order_id = array_shift( explode( '.', $end ) );

			$order = new WC_Order( $order_id );
			$user_id = get_current_user_id();

			if ( $order->user_id != $user_id ) {
				global $wp_query;
				$wp_query->set_404();
				status_header( 404 );
				get_template_part( 404 ); exit();
			}

			global $wpdb;

			$product_keys = get_post_meta( $order_id, '_keys' );

			$product_keys = $product_keys[0];

			$fh = fopen( 'php://output', 'w' );

			ob_start();

			$headers = array( 'Product', 'Key', 'Status', 'User', 'Enrollment Date' );

				fputcsv( $fh, $headers );

			foreach ( $product_keys as $product ) {

				$product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $product['product_sku'] ) );

				if ( $product_id ) $woo_product = new WC_Product( $product_id );
				else $woo_product = null;

				foreach ( $product['keys'] as $key ) {

					$status = $this->is_enrollment_active( $key ) == 0 ? 'Available' : 'Enrolled';
					$status = $this->is_enrollment_expired( $key ) == 0 ? $status : 'Expired';

					if ( $status == 'Enrolled' ) {
						$enrollment = $this->get_enrollment( array( 'activation_key' => $key ) );
						$user = get_user_by( 'id', $enrollment['user_id'] );
						$user_out = $user->user_nicename;
					} else {
						$enrollment = null;
						$user = null;
						$user_out = null;
					}

					$line = array();
					array_push( $line, $woo_product->post->post_title . ' [SKU: ' . $product['product_sku'] . ']' );
					array_push( $line, $key );
					array_push( $line, $status );
					array_push( $line, $user_out );
					array_push( $line, $enrollment['activation_date'] );

					fputcsv( $fh, $line );
				}

			}

			header( 'Pragma: public' );
			header( 'HTTP/1.0 200 OK' );
			header( 'Expires: 0' );
			header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
			header( 'Cache-Control: private', false );
			header( 'Content-Type: text/csv' );
			header( 'Content-Disposition: attachment; filename="Order_' . $order_id . '.csv";' );
			header( 'Content-Transfer-Encoding: binary' );
			$string = ob_get_clean();
			exit( $string );

		}


		/**
		 * Loads refund script for refunded orders
		 * Script add 'deactivate-keys' checkbox on 'refunded' status change
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-04-28 16:57:59
		 *
		 */
		function refund_script() {
			global $current_screen;

			if ( $_GET['action'] != 'edit' || $current_screen->post_type != 'shop_order' ) return;

			wp_enqueue_script( 'propel-refund', plugin_dir_url( __FILE__ ) . 'js/refunds.js' );
		}


		/**
		 * When a course order is refunded this
		 *   Deactivates the keys through the OKM
		 *   Unenrolls the any activated keys
		 *
		 * @author caseypatrickdriscoll
		 *
		 * @created 2015-04-28 17:03:44
		 *
		 * @action  save_post_shop_order
		 *
		 */
		function refund_orders( $post_id ) {

			error_log( 'Shall I refund?  ' . print_r($post_id, 1) );

			global $wp_current_filter;

			if ( $wp_current_filter[0] == 'save_post' ) return;


			// STANDARD CHECKS

			// Autosave, do nothing
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;


			// Check user permissions
			if ( ! current_user_can( 'edit_post', $post_id ) ) return;


			// Return if it's a post revision
			if ( false !== wp_is_post_revision( $post_id ) ) return;



			// END STANDARD CHECKS
			error_log(print_r($_POST, true));

			if ( ! $_POST['restock_refunded_items'] ) return;

			error_log( 'After refunded and deactivate is true  ' . print_r($post_id, 1));

			$user = wp_get_current_user();
			$propel_settings = get_option( 'propel_settings' );

			// Deactivate keys through OKM
			$post_data = array(
				'tenant_secret_key' => $propel_settings['okm_tenant_secret_key'],
				'order_number' => "$post_id",
				'ext_user_id' => "$user->ID",
			);

			$response = self::ping_api( $post_data, 'deactivate_keys' );

			// Unenroll each of the keys
			if ( $response['http_status'] == 200 ) {
					foreach ( $response['api'] as $key ) {
						$this->unenroll_key( $key['code'] );
					}
			}


		}


		/**
		 * Unenrolls a key in the enrollments table
		 * Unenrollment means setting expiration date to now
		 *
		 * @author  caseypatrickdriscoll
		 *
		 * @created 2015-04-29 15:20:44
		 *
		 * @param   $key   The key code to search and destroy
		 */
		function unenroll_key( $key ) {

			global $wpdb;

			$enrollments_table = $wpdb->prefix . Propel_DB::enrollments_table;

			$enrollment = $wpdb->get_row( "SELECT * FROM $enrollments_table WHERE activation_key = '$key'" );

			if ( $enrollment != null ) {
				$wpdb->update(
					$enrollments_table,
					array( 'expiration_date' => date("Y-m-d H:i:s") ),
					array( 'activation_key'  => $key )
				);
			}

		}


}

new Propel_LMS();
